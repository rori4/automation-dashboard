import DefaultLayout from './DefaultLayout';

export { DefaultLayout };
